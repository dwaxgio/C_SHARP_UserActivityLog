USE [ActivityLog]
GO

INSERT INTO [dbo].[Login]
           ([Username]
           ,[EmployeeNo]
           ,[Password]
           ,[Type]
           ,[Status])
     VALUES
           (
			'Edward'
			,1001
			,1111
			,'A'
			,'Active'
		   )
GO


