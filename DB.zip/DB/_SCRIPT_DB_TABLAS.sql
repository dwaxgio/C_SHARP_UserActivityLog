CREATE DATABASE ActivityLog
go

USE ActivityLog
GO

CREATE TABLE dbo.Login
(
	Username nchar(10),
	EmployeeNo nchar(10),
	Password nvarchar(50),
	Type nvarchar(50),
	Status nvarchar(50)
)

CREATE TABLE dbo.User_Activity_Log
(
	UserId nchar(10),
	EmployeeNo nchar(10),
	Timestamp nvarchar(max),
	FunctionPerformed nvarchar(max),
	IPAddress nchar(15)
)